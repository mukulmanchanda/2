import { AccountDetailsComponent } from './account-details/account-details.component';
import { MyMediaPageComponent } from './my-media-page/my-media-page.component';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
    {path: "", redirectTo: "app-root", pathMatch: "full"},
    {path : 'home', component : HomeComponent},
    {path : 'register',component :RegisterComponent},
    {path : 'my-media-page' ,component :MyMediaPageComponent},
    {path : 'account-details',component :AccountDetailsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingcomponents= [HomeComponent,RegisterComponent,MyMediaPageComponent,AccountDetailsComponent]; 


